<?php
/**
 * Plugin Name: TreeCam Gallery
 * Plugin URI: https://jessicakmurray.com/
 * Description: Scrapes images from a specified folder and displays them as a gallery.
 * Version: 1.2
 * Author: Jessica Murray
 * Author URI: https://JessicaKMurray.com/
 * License: GPL2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Enqueue Lightbox2 CSS and JS
function treecam_enqueue_lightbox_assets() {
    wp_enqueue_style('lightbox2', 'https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css');
    wp_enqueue_script('lightbox2', 'https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js', ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'treecam_enqueue_lightbox_assets');

// Add Admin Settings Page
function treecam_add_admin_menu() {
    add_options_page(
        'TreeCam Gallery Settings',   // Page title
        'TreeCam Gallery',            // Menu title
        'manage_options',             // Capability
        'treecam-gallery',            // Menu slug
        'treecam_settings_page'       // Callback function
    );
}
add_action('admin_menu', 'treecam_add_admin_menu');

// Register Settings
function treecam_register_settings() {
    register_setting('treecam_settings_group', 'treecam_base_url'); // Use a clear setting name for the base URL
}
add_action('admin_init', 'treecam_register_settings');

// Render Admin Settings Page
function treecam_settings_page() {
    ?>
    <div class="wrap">
        <h1>TreeCam Gallery Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('treecam_settings_group');
            do_settings_sections('treecam_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Base URL</th>
                    <td>
                        <input type="text" name="treecam_base_url" value="<?php echo esc_attr(get_option('treecam_base_url', 'https://jessicakmurray.com/mptreefiles/treecam/')); ?>" style="width: 100%;" />
                        <p class="description">Enter the absolute URL to the folder containing the images (e.g., <code>https://jessicakmurray.com/mptreefiles/treecam/</code>).</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Get Images Function (Handles Absolute URLs)
function treecam_get_images() {
    $base_url = rtrim(get_option('treecam_base_url', 'https://jessicakmurray.com/mptreefiles/treecam/'), '/'); // Get the base URL and remove trailing slash
    $images = [];

    // Parse the base URL to determine the absolute path on the server
    $parsed_url = parse_url($base_url);
    $base_path = $_SERVER['DOCUMENT_ROOT'] . $parsed_url['path'];

    if (is_dir($base_path)) {
        $directory = new RecursiveDirectoryIterator($base_path);
        $iterator = new RecursiveIteratorIterator($directory);
        foreach ($iterator as $file) {
            if (preg_match('/\.(jpg|jpeg|png|gif)$/i', $file->getFilename())) {
                $relative_path = str_replace($base_path, '', $file->getPathname());
                $images[] = [
                    'url' => $base_url . '/' . ltrim($relative_path, '/'), // Full URL of the image
                    'path' => $file->getPathname(),                      // Absolute server path
                    'time' => filemtime($file->getPathname()),           // Last modified time
                ];
            }
        }
    }

    // Sort images by time (newest first).
    usort($images, function ($a, $b) {
        return $b['time'] - $a['time'];
    });

    return $images;
}

// Gallery Shortcode
function treecam_gallery_shortcode() {
    $images = treecam_get_images();

    if (empty($images)) {
        return '<p>No images found in the specified folder.</p>';
    }

    // Output the gallery.
    $output = '<div class="treecam-gallery">';

    foreach ($images as $index => $image) {
        if ($index === 0) {
            // Display the most recent image with 640x480 dimensions.
            $output .= '<div class="treecam-featured">';
            $output .= '<a href="' . esc_url($image['url']) . '" data-lightbox="treecam-gallery" data-title="Featured Image">';
            $output .= '<img src="' . esc_url($image['url']) . '" alt="Featured Image" style="width:640px;height:480px;object-fit:cover;" />';
            $output .= '</a>';
            $output .= '</div>';
        } else {
            // Display other images in smaller thumbnails.
            $output .= '<div class="treecam-thumbnail">';
            $output .= '<a href="' . esc_url($image['url']) . '" data-lightbox="treecam-gallery" data-title="TreeCam Image">';
            $output .= '<img src="' . esc_url($image['url']) . '" alt="TreeCam Image" style="max-width:150px;height:auto;margin:5px;" />';
            $output .= '</a>';
            $output .= '</div>';
        }
    }

    $output .= '</div>';

    // Add basic styles.
    $output .= '<style>
        .treecam-gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .treecam-featured {
            flex-basis: 100%;
            margin-bottom: 20px;
        }
        .treecam-thumbnail {
            flex-basis: auto;
        }
    </style>';

    return $output;
}
add_shortcode('treecam_gallery', 'treecam_gallery_shortcode');
